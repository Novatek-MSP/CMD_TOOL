# CMD_TOOL
Novatek MSP Touch IC Command Line Tool
